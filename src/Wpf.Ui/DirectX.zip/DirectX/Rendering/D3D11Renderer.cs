// This Source Code Form is subject to the terms of the MIT License.
// If a copy of the MIT was not distributed with this file, You can obtain one at https://opensource.org/licenses/MIT.
// Copyright (C) Leszek Pomianowski and WPF UI Contributors.
// All Rights Reserved.

using System.Diagnostics;
using System.Numerics;
using System.Runtime.InteropServices;

using Vortice.Direct3D11;
using Vortice.DXGI;
using Vortice.Mathematics;

using Wpf.Ui.DirectX.Models;
using Wpf.Ui.DirectX.Services;
using Wpf.Ui.DirectX.Threading;

using MapFlags = Vortice.Direct3D11.MapFlags;

namespace Wpf.Ui.DirectX.Rendering;

public sealed class D3D11Renderer : IRenderable, IDisposable
{
    private readonly ID3DGraphicsService _graphicsService;
    private readonly IRenderThreadService _renderThread;
    private readonly IReadOnlyList<IGraphSeries> _seriesList;
    private readonly SeriesRendererManager _rendererManager;
    private readonly ID3D11Device _device;
    private readonly ID3D11DeviceContext _context;
    private ID3D11RenderTargetView? _renderTargetView;
    private IDXGISwapChain? _swapChain;
    private ID3D11Buffer? _viewProjectionBuffer;

    private readonly IntPtr _hwnd;
    private readonly int _width;
    private readonly int _height;

    private bool _disposed;
    private int _isUpdatingViewProjection = 0;

    private readonly TimeSpan _minReinitInterval = TimeSpan.FromSeconds(5);

    public bool IsReady => _device.NativePointer != IntPtr.Zero && _context.NativePointer != IntPtr.Zero;

    public double Width => _width;

    public double Height => _height;

    public ID3D11Device Device => _device;

    public ID3D11DeviceContext Context => _context;

    // 생성자: 최초 한 번만 호출, 재초기화는 별도 메서드로 처리
    public D3D11Renderer(ID3DGraphicsService graphicsService, IRenderThreadService renderThread,
                         IntPtr hwnd, int width, int height,
                         IReadOnlyList<IGraphSeries> seriesList,
                         SeriesRendererManager rendererManager)
    {
        _graphicsService = graphicsService;
        _renderThread = renderThread;
        _hwnd = hwnd;
        _width = width;
        _height = height;
        _seriesList = seriesList;
        _rendererManager = rendererManager;

        _device = _graphicsService.Device;
        _context = _graphicsService.Context;

        InitializeResources();
    }

    private void InitializeResources()
    {
        DisposeResources(); // ✅ 항상 기존 리소스 정리 후 시작

        _swapChain = ((IDXGIFactory1)_graphicsService.Factory).CreateSwapChain(_device, new SwapChainDescription
        {
            BufferDescription = new ModeDescription((uint)_width, (uint)_height, new Rational(60, 1), Format.B8G8R8A8_UNorm),
            SampleDescription = new SampleDescription(1, 0),
            BufferUsage = Usage.RenderTargetOutput,
            BufferCount = 1,
            OutputWindow = _hwnd,
            Windowed = true,
            SwapEffect = SwapEffect.Discard,
            Flags = SwapChainFlags.None
        });

        using ID3D11Texture2D backBuffer = _swapChain.GetBuffer<ID3D11Texture2D>(0);
        _renderTargetView = _device.CreateRenderTargetView(backBuffer);

        // 초기 ViewProjectionBuffer 생성
        CreateViewProjectionBuffer();

        Debug.WriteLine("✅ Renderer resources initialized.");
    }

    private void CreateViewProjectionBuffer()
    {
        var bufferDesc = new BufferDescription(
            (uint)Marshal.SizeOf<Vector4>(),
            BindFlags.ConstantBuffer,
            ResourceUsage.Dynamic,
            CpuAccessFlags.Write,
            ResourceOptionFlags.None,
            0
        );

        _viewProjectionBuffer = _device.CreateBuffer(bufferDesc);
    }

    private void DisposeResources()
    {
        static void SafeDispose<T>(ref T? resource)
            where T : class, IDisposable
        {
            resource?.Dispose();
            resource = null;
        }

        SafeDispose(ref _viewProjectionBuffer);
        SafeDispose(ref _renderTargetView);
        SafeDispose(ref _swapChain);

        Debug.WriteLine("🧹 All GPU resources disposed.");
    }

    public void SetTransform(float xOffset, float xScale, float yScale, float yOffset = 0f)
    {
        if (_disposed || _viewProjectionBuffer == null)
        {
            return;
        }

        if (Interlocked.Exchange(ref _isUpdatingViewProjection, 1) == 1)
        {
            return;
        }

        try
        {
            var data = new Vector4(xScale, yScale, xOffset, yOffset);
            MappedSubresource mapped = _context.Map(_viewProjectionBuffer, 0, MapMode.WriteDiscard, MapFlags.None);
            Marshal.StructureToPtr(data, mapped.DataPointer, false);
            _context.Unmap(_viewProjectionBuffer, 0);
        }
        catch (Exception ex)
        {
            Debug.WriteLine($"UpdateViewProjectionBuffer failed: {ex.Message}");
        }
        finally
        {
            _ = Interlocked.Exchange(ref _isUpdatingViewProjection, 0);
        }
    }

    public void RenderFrame(float time)
    {
        if (_disposed || !IsReady)
        {
            return;
        }

        // 예시로 기본 transform 설정 (전체 화면 좌표 맞춤)
        SetTransform(0f, 1f, 1f, 0f);
        _context.OMSetRenderTargets(_renderTargetView);
        _context.ClearRenderTargetView(_renderTargetView, new Color4(0, 0, 0, 1));
        _context.RSSetViewport(new Viewport(0, 0, (int)_width, (int)_height, 0, 1));
        _context.VSSetConstantBuffer(0, _viewProjectionBuffer);

        var batcher = new DrawGroupBatcher();
        foreach (IGraphSeries series in _seriesList)
        {
            if (!series.IsVisible || !series.IsReady)
            {
                continue;
            }

            var renderer = _rendererManager.GetRenderer(series);
            if (renderer is IRenderStyleKeyProvider)
            {
                batcher.Add((dynamic)series, (dynamic)renderer);
            }
        }

        batcher.Execute(_context);

        try
        {
            _ = _swapChain?.Present(0, PresentFlags.None);
        }
        catch (Exception ex)
        {
            Debug.WriteLine($"Present failed: {ex.Message}");
        }
    }

    public void Resize(int width, int height)
    {
        DisposeResources();
        InitializeResources();
    }

    public bool IsContextValid()
    {
        try
        {
            if (_context == null || _context.NativePointer == IntPtr.Zero || _disposed)
            {
                Debug.WriteLine("❌ Invalid context");
            }

            // Context가 여전히 유효한지 확인
            return _context != null &&
                   _context.NativePointer != IntPtr.Zero &&
                   !_disposed;
        }
        catch
        {
            return false;
        }
    }

    public bool IsDeviceValid()
    {
        try
        {
            return _device != null &&
                   _device.NativePointer != IntPtr.Zero &&
                   !_disposed;
        }
        catch
        {
            return false;
        }
    }

    public void Dispose()
    {
        if (_disposed)
        {
            return;
        }

        _disposed = true;
        _renderThread.Unregister(this);
        DisposeResources();
    }
}