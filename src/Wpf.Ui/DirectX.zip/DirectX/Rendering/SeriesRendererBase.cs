// This Source Code Form is subject to the terms of the MIT License.
// If a copy of the MIT was not distributed with this file, You can obtain one at https://opensource.org/licenses/MIT.
// Copyright (C) Leszek Pomianowski and WPF UI Contributors.
// All Rights Reserved.

using Vortice.Direct3D11;
using Vortice.Mathematics;

using Wpf.Ui.DirectX.Models;
using Wpf.Ui.DirectX.Models.VertexTypes;

namespace Wpf.Ui.DirectX.Rendering;

public interface IRenderStyleKeyProvider
{
    DrawKey GetDrawKey();
}

public readonly record struct DrawKey(
    PixelShaderType ShaderType,
    Color4 Color,
    Vortice.Direct3D.PrimitiveTopology Topology,
    string LayoutKey // 예: "POSITION", "POSITION+COLOR"
);

public abstract class SeriesRendererBase<T>
    where T : unmanaged
{
    protected readonly GraphSeries<T> _series;
    protected readonly ID3D11Device _device;
    protected readonly ID3D11DeviceContext _context;

    protected SeriesRendererBase(GraphSeries<T> series, ID3D11Device device, ID3D11DeviceContext context)
    {
        _series = series;
        _device = device;
        _context = context;
        InitializeShaders();
        InitializeBuffers();
    }

    protected abstract void InitializeShaders();

    protected abstract void InitializeBuffers();

    public abstract void Upload(ID3D11DeviceContext context);

    public abstract void Draw(ID3D11DeviceContext context);

    public abstract DrawKey GetDrawKey();
}
