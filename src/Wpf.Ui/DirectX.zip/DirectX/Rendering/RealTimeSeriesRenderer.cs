// This Source Code Form is subject to the terms of the MIT License.
// If a copy of the MIT was not distributed with this file, You can obtain one at https://opensource.org/licenses/MIT.
// Copyright (C) Leszek Pomianowski and WPF UI Contributors.
// All Rights Reserved.

using SharpGen.Runtime;

using System.IO;
using System.Runtime.InteropServices;

using Vortice.D3DCompiler;
using Vortice.Direct3D;
using Vortice.Direct3D11;
using Vortice.DXGI;
using Vortice.Mathematics;

using Wpf.Ui.DirectX.Models;
using Wpf.Ui.DirectX.Models.VertexTypes;

namespace Wpf.Ui.DirectX.Rendering;

public sealed class RealTimeSeriesRenderer<T> : SeriesRendererBase<T>, IRenderStyleKeyProvider
    where T : unmanaged
{
    private ID3D11Buffer? _vertexBuffer;
    private int _vertexCount;
    private int _bufferSizeInBytes = 0;

    // 임사
    private ID3D11VertexShader? _vertexShader;
    private ID3D11VertexShader? _vertexShaderConst;
    private ID3D11PixelShader? _pixelShaderVertexColor;
    private ID3D11PixelShader? _pixelShaderConstColor;
    private ID3D11InputLayout? _inputLayout;
    private ID3D11InputLayout? _inputLayoutConst;
    private ID3D11Buffer? _graphColorBuffer;

    public RealTimeSeriesRenderer(RealTimeSeries<T> series, ID3D11Device device, ID3D11DeviceContext context)
        : base(series, device, context)
    {
    }

    public override void Upload(ID3D11DeviceContext context)
    {
        if (_series is not RealTimeSeries<T> realSeries || !_series.IsReady)
        {
            return;
        }

        ReadOnlySpan<T> data = realSeries.GetSpanUnsafe();
        _vertexCount = data.Length;

        if (_vertexCount == 0)
        {
            _vertexBuffer?.Dispose();
            _vertexBuffer = null;
            _bufferSizeInBytes = 0;
            return;
        }

        int sizeInBytes = Marshal.SizeOf<T>() * _vertexCount;
        if (_vertexBuffer == null || sizeInBytes > _bufferSizeInBytes)
        {
            _vertexBuffer?.Dispose();
            _bufferSizeInBytes = (int)(sizeInBytes * 1.25f);
            _vertexBuffer = VertexBufferFactory.CreateVertexBuffer<T>(
                _device, context, Span<T>.Empty, true, _bufferSizeInBytes);
        }

        _ = VertexBufferFactory.UploadVertices(_device, context, _vertexBuffer!, data);
    }

    protected override void InitializeShaders()
    {
        string vsPath = Path.Combine(AppContext.BaseDirectory, "Assets", "LineVertexShader.hlsl");
        string vsConstPath = Path.Combine(AppContext.BaseDirectory, "Assets", "ConstVertexShader.hlsl");
        string psVertexPath = Path.Combine(AppContext.BaseDirectory, "Assets", "LinePixelShader.hlsl");
        string psConstPath = Path.Combine(AppContext.BaseDirectory, "Assets", "ConstPixelShader.hlsl");

        Result vsResult = Compiler.CompileFromFile(vsPath, "VSMain", "vs_5_0", out Blob? vsBytecode, out Blob? vsErr);
        Result vsConstResult = Compiler.CompileFromFile(vsConstPath, "VSMain", "vs_5_0", out Blob? vsConstBytecode, out Blob? vsConstErr);

        Result psResult = Compiler.CompileFromFile(psVertexPath, "PSMain", "ps_5_0", out Blob? psVertexBytecode, out Blob? psErr);
        Result constResult = Compiler.CompileFromFile(psConstPath, "PSMain", "ps_5_0", out Blob? psConstBytecode, out Blob? constErr);

        if (vsConstResult.Failure || vsConstBytecode == null)
        {
            throw new InvalidOperationException(vsConstErr?.AsString() ?? "Const Vertex shader error.");
        }

        if (vsResult.Failure || vsBytecode == null)
        {
            throw new InvalidOperationException(vsErr?.AsString() ?? "Vertex shader error.");
        }

        if (psResult.Failure || psVertexBytecode == null)
        {
            throw new InvalidOperationException(psErr?.AsString() ?? "Pixel shader error.");
        }

        if (constResult.Failure || psConstBytecode == null)
        {
            throw new InvalidOperationException(constErr?.AsString() ?? "Const Pixel shader error.");
        }

        _vertexShader = _device.CreateVertexShader(vsBytecode);
        _vertexShaderConst = _device.CreateVertexShader(vsConstBytecode);

        _pixelShaderVertexColor = _device.CreatePixelShader(psVertexBytecode);
        _pixelShaderConstColor = _device.CreatePixelShader(psConstBytecode);

        _inputLayout = _device.CreateInputLayout(
            new InputElementDescription[]
            {
                new InputElementDescription("POSITION", 0, Format.R32G32B32_Float, 0, 0),
                new InputElementDescription("COLOR", 0, Format.R32G32B32A32_Float, 12, 0)
            },
            vsBytecode
        );

        // ✅ 전용 InputLayout: POSITION only
        _inputLayoutConst = _device.CreateInputLayout(
            new InputElementDescription[]
            {
        new InputElementDescription("POSITION", 0, Format.R32G32B32_Float, 0, 0)
            },
            vsConstBytecode
        );

        vsBytecode.Dispose();
        psVertexBytecode.Dispose();
        psConstBytecode.Dispose();
        vsErr?.Dispose();
        psErr?.Dispose();
        constErr?.Dispose();
    }

    protected override void InitializeBuffers()
    {
        // 초기 VertexBuffer 생성
        CreateGraphColorBuffer();
    }

    private void CreateGraphColorBuffer()
    {
        var desc = new BufferDescription(
            (uint)Marshal.SizeOf<Color4>(),
            BindFlags.ConstantBuffer,
            ResourceUsage.Dynamic,
            CpuAccessFlags.Write);

        _graphColorBuffer = _device.CreateBuffer(desc);
    }

    private void UpdateGraphColorBuffer(Color4 color)
    {
        MappedSubresource mapped = _context.Map(_graphColorBuffer, 0, MapMode.WriteDiscard, Vortice.Direct3D11.MapFlags.None);
        Marshal.StructureToPtr(color, mapped.DataPointer, false);
        _context.Unmap(_graphColorBuffer, 0);
    }

    public override void Draw(ID3D11DeviceContext context)
    {
        if (!_series.IsReady || _vertexBuffer == null || _vertexCount == 0)
        {
            return;
        }

        int stride = Marshal.SizeOf<T>();
        int offset = 0;

        _context.VSSetShader(_vertexShaderConst);
        _context.IASetInputLayout(_inputLayoutConst);
        _context.PSSetShader(_pixelShaderConstColor);
        UpdateGraphColorBuffer(_series.GraphColor);
        _context.PSSetConstantBuffer(1, _graphColorBuffer);
        _context.IASetVertexBuffers(0, new[] { _vertexBuffer }, new uint[] { (uint)stride }, new uint[] { (uint)offset });
        _context.IASetPrimitiveTopology(Vortice.Direct3D.PrimitiveTopology.TriangleList);
        _context.Draw((uint)_vertexCount, 0);
    }

    public override DrawKey GetDrawKey()
    {
        return new DrawKey(
            PixelShaderType.ConstantColor,
            _series.GraphColor,
            Vortice.Direct3D.PrimitiveTopology.LineStrip,
            VertexLayoutKey.Get<T>()
            );
    }
}