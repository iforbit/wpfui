// This Source Code Form is subject to the terms of the MIT License.
// If a copy of the MIT was not distributed with this file, You can obtain one at https://opensource.org/licenses/MIT.
// Copyright (C) Leszek Pomianowski and WPF UI Contributors.
// All Rights Reserved.

using System.Runtime.CompilerServices;

using Wpf.Ui.DirectX.Models.VertexTypes;

namespace Wpf.Ui.DirectX.Models;

public sealed class RealTimeSeries<T> : GraphSeries<T>
    where T : unmanaged
{
    private readonly RingBuffer<T> _ringBuffer;
    private readonly List<T> _historyCache = new();
    private readonly object _lock = new();
    private float _lastX = 0f;
    private float _minX = float.MaxValue;
    private float _maxX = float.MinValue;

    public float LastX => _lastX;

    public float MinX => _minX;

    public float MaxX => _maxX;

    public int TotalVertexCount => _ringBuffer.Count;

    public bool EnableAutoTrim { get; set; } = true;

    public bool UseHistoryCache { get; set; } = false;

    public int MaxBufferLength { get; set; } = 100_000;

    public RealTimeSeries(int capacity = 8192)
    {
        _ringBuffer = new RingBuffer<T>(capacity);
    }

    protected override void OnInitialize()
    {
        _ringBuffer.Clear();
        _historyCache.Clear();
        _lastX = 0f;
        _minX = float.MaxValue;
        _maxX = float.MinValue;
    }

    public override void Append(ReadOnlySpan<T> data)
    {
        lock (_lock)
        {
            _ringBuffer.Append(data);

            foreach (ref readonly T point in data)
            {
                if (typeof(T) == typeof(VertexPosition))
                {
                    float x = Unsafe.As<T, VertexPosition>(ref Unsafe.AsRef(in point)).Position.X;
                    _lastX = Math.Max(_lastX, x);
                    _minX = Math.Min(_minX, x);
                    _maxX = Math.Max(_maxX, x);
                }
                else if (typeof(T) == typeof(VertexPositionColor))
                {
                    float x = Unsafe.As<T, VertexPositionColor>(ref Unsafe.AsRef(in point)).Position.X;
                    _lastX = Math.Max(_lastX, x);
                    _minX = Math.Min(_minX, x);
                    _maxX = Math.Max(_maxX, x);
                }

                if (UseHistoryCache)
                {
                    _historyCache.Add(point);
                }
            }
        }
    }

    public void GetYRange(float minX, float maxX, out float minY, out float maxY)
    {
        lock (_lock)
        {
            minY = float.MaxValue;
            maxY = float.MinValue;

            _ringBuffer.GetSpans(out Span<T> span1, out Span<T> span2);
            ExtractY(span1, minX, maxX, ref minY, ref maxY);
            ExtractY(span2, minX, maxX, ref minY, ref maxY);

            if (minY == float.MaxValue || maxY == float.MinValue)
            {
                minY = -1f;
                maxY = 1f;
            }
        }
    }

    private void ExtractY(ReadOnlySpan<T> span, float minX, float maxX, ref float minY, ref float maxY)
    {
        foreach (ref readonly T point in span)
        {
            float x, y;
            if (typeof(T) == typeof(VertexPosition))
            {
                VertexPosition p = Unsafe.As<T, VertexPosition>(ref Unsafe.AsRef(point));
                x = p.Position.X;
                y = p.Position.Y;
            }
            else if (typeof(T) == typeof(VertexPositionColor))
            {
                VertexPositionColor p = Unsafe.As<T, VertexPositionColor>(ref Unsafe.AsRef(point));
                x = p.Position.X;
                y = p.Position.Y;
            }
            else
            {
                continue;
            }

            if (x >= minX && x <= maxX)
            {
                minY = Math.Min(minY, y);
                maxY = Math.Max(maxY, y);
            }
        }
    }

    public ReadOnlySpan<T> GetSpanUnsafe()
    {
        lock (_lock)
        {
            return _ringBuffer.AsSpanUnsafe();
        }
    }
}
